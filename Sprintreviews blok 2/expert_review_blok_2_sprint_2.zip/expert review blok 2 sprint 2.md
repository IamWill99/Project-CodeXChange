﻿Expert review

Deze expert review is via de starrt methode.

Situatie: in mijn expert review wil ik de onderstaande code bespreken.                                      

` `Navigatie bar in html en typescript code:

![Afbeelding met tekst, schermopname, scherm, software

Automatisch gegenereerde beschrijving](Aspose.Words.6eb85c0b-1c7a-4b6d-8f6c-f3bdd2f4163c.001.png)

![Afbeelding met tekst, schermopname, Lettertype

Automatisch gegenereerde beschrijving](Aspose.Words.6eb85c0b-1c7a-4b6d-8f6c-f3bdd2f4163c.002.png)

Regex code:

![Afbeelding met tekst, schermopname, software

Automatisch gegenereerde beschrijving](Aspose.Words.6eb85c0b-1c7a-4b6d-8f6c-f3bdd2f4163c.003.png)

Taak: Wat ik lastig vond bij het schrijven van de code was dat ik lang bezig was om in de navigatie bar functie ervoor te zorgen dat de functie werkt om het menu te openen en om met dezelfde knop weer te sluiten. Dit heb ik uiteindelijk opgelost door een queryselectorAll te gebruiken. 

Aanpak: Ik heb de lastige taak aangepakt door eerst veel onderzoek te doen op internet. En toen het toen nog steeds niet lukte heb ik de leraar om hulp gevraagd waardoor ik uiteindelijk wist wat ik moest doen om het te laten werken.

Resultaat: 

**Feedback van Jeffrey:**

Ik heb als feedback gekregen dat ik voor de registratie functie ervoor moet zorgen dat de eisen voor het wachtwoord en de email duidelijk worden wegegeven zodat mensen sneller en overzichtelijker een account kunnen aanmaken. Ook werd er gezegd dat we rekening moeten houden met mensen met een handicap die minder makkelijk het internet kunnen gebruiken. Hiervoor moeten we de website dus zo maken dat hij voor iedereen toegankelijk en begrijpelijk is.

Omdat we nog niet veel geprogrammeerd hebben omdat we in het begin van het blok vooral bezig waren met het maken van plannen voor de website zoals mindmaps, prototypes, wireflows. Heb ik nog niet veel object georiënteerd geprogrammeerd , maar we hebben wel al in een stappen plan bedacht hoe we dat gaan aanpakken.

- eerst willen we leren wat object georiënteerd programmeren allemaal inhoud en aan welke regels wij ons moeten houden als we zo te werk gaan.
- Daarna willen we de al gemaakte code aanpassen zodat deze ook object georiënteerd is.
- Als dat klaar is willen we een uml van onze erd maken zodat we daarna een eigen database kunnen aanmaken die we voor onze website gaan gebruiken
- Als dat allemaal gedaan is gaan we de rest van de code om de website functioneel te maken schrijven.

**Feedback van Ruben van der Meer:**

Ik heb als feedback gekregen dat ik samen met mijn duo er voor moet zorgen dat we van tevoren al een planning maken voor sprint 3, omdat ons nog veel werk te doen staat om het project te kunnen afronden. Zo moeten we bijvoorbeeld nog een database maken en nog een hoop code in typescript schrijven om de functies die wij on onze website willen hebben functioneel te maken, zodat we aan het eind van sprint 3 een functionele website hebben. Wat we goed hebben gedaan is dat we al hebben nagedacht over hoe we de database gaan maken, dit hebben we gedaan in de vorm van een ERD en een UML. Dit moeten we dus wel zo snel mogelijk af hebben zodat we verder kunnen. Ook moeten we een test planning gaan maken zodat we onze website genoeg testen en dus niet alleen aan het eind van de derde sprint. Verder moeten we ook nog gaan kijken hoe we onze website toegankelijk kunnen maken voor iedereen, hierbij moeten we ook rekening houden met onze planning en wat voor effect dit op onze planning gaat hebben.

reflectie: Ik heb van de feedback geleerd dat we de website zo duidelijk en gebruikers vriendelijk mogelijk te maken. Dit kunnen we dus doen door het overzichtelijk, toegankelijk en goed te begrijpen te maken. En dat we goed moeten bedenken hoe we het programmeren zelf gaan aanpakken zodat we aan het eind van het blok ons gewenste resultaat gaan bereiken. Ook moeten we voor de derde sprint een goede planning gaan maken om dus al het werk af te kunnen maken. Voor de rest moeten we zo snel mogelijk de database afhebben om dus de website werkend te kunnen maken.

transfer: In het vervolg ga ik meer rekening houden met de gebruikers van de website. En dat we de ervaring van hun bij het gebruik van de website zo goed mogelijk te maken. Ook ga ik me bezig houden met het object georiënteerd programmeren van de website, en het maken van een functionele database. Ook ga ik samen met mijn duo een goede planning maken voor sprint 3, om zoveel mogelijk user en learning story’s af te kunnen maken in sprint 3.


