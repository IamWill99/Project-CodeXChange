﻿William Boutros

Expert review blok 2 14-12-2023

Deze expert review is aan de hand van de STARRT-methode gemaakt.

# Situatie
Voor de voorbereiding van de expert review bekijk ik de code die ik tot nu toe in blok 2 heb geprogrammeerd. Deze code bestaat uit een registratie functie, waar de User de gegevens stuurt naar de database. Zo kan de User in de toekomst inloggen op de website.
# Taak
Voor de opleiding had ik geen programmeer ervaring, dus alles moest geleerd worden. HTML en CSS kon ik snel oppakken, maar met typescript heb ik meer moeite. Er is niet veel informatie specifiek over typescript beschikbaar op de knowledgebase. Daarbij moest ik veel vragen stellen over het maken van een database. 
# Aanpak
Om typescript te leren heb ik vragen gesteld in de les, YouTube tutorials bekeken en W3schools doorgelezen. Zo heb ik geleerd om een registratiesysteem te bouwen voor nieuwe Users. Daarbij ben ik naar de docent gegaan voor het bouwen van een database. Hier zijn we begonnen met het maken van een ERD. 
# Resultaat
**Oscar heeft mij de volgende feedback gegeven:**

Goed uitgelegd, ERD ziet er goed uit en ik snap de achterliggende theorie. Verder zag de code van de registratiesysteem er goed uit. We nemen de juiste stappen. Wel moet ik letten op de kwantiteit van code. Er is naast de ERD, UML en database waar een User kan registreren niet veel meer. We zijn vooral bezig geweest met prototypes, een flowchart, guerilla tests en mindmaps voor de opbouw van de website. Dus er is nog niet gewerkt aan object georiënteerd programmeren. Ook moeten we G10 onthouden, zodat mensen met een beperking ook straks gebruik kunnen maken van de website.

We gaan de volgende stappen nemen voor mensen met een beperking:

- Een simpele lay-out waar alle informatie duidelijk te zien is
- Geen kleuren die mensen met kleurenblindheid niet kunnen waarnemen
- Afbeeldingen krijgen een tekstbeschrijving, zodat blinde mensen deze ook kunnen begrijpen

Voor object georiënteerd programmeren nemen we de volgende stappen:

- Theorie leren over OOP zoals abstraction, inheritance en encapsulation via de gegeven learningstory
- Werken met constructors
- UML omzetten naar een werkend product

**Feedback Ruben van der Meer:**

Goed dat ik bezig ben met de UML van het project, maar het was beter als ik al verder was geweest met programmeren. Vanwege het gebrek aan programmeren zal ik minder tijd overhouden in sprint 3 om te gaan testen. Ook moet ik letten op dat het product niet te ingewikkeld wordt. Het is beter om eerst een werkend product te hebben waar Users vragen en antwoorden kunnen plaatsen. Verder is het verstandig om een testplanning te maken om rekening te houden met de tijd en uitslagen van tests. Zo kan ik noteren waar het mis is gegaan in een test, waardoor je sneller aanpassingen kan aanbrengen. Dus zo snel mogelijk aan de slag om een werkend product te krijgen. Tot slot zou ik rekening moeten houden met de toegankelijkheid van de website, waar ik wel al wat ideeën voor had.**

# Reflectie
Ik heb geleerd dat ik de juiste stappen aan het ondernemen ben voor het bouwen van een database. Het is belangrijk dat ik de achterliggende theorie snap, waardoor ik minder vaak vastloop tijdens de opdrachten. Wel zou ik meer uren moeten besteden aan het project. De kwaliteit is goed, de kwantiteit is minder. Zo snel mogelijk een werkend product maken. Verder heb ik geleerd dat ik moet letten op gedragscriteria G10, waar de website toegankelijk moet zijn voor mensen met een beperking. Hierboven heb ik enkele stappen gemaakt om onze website toegankelijk te maken.
# Transfer
Ik neem mee voor de volgende sprints dat ik meer tijd moet besteden aan het project. Vooral aan de database, UML en object georiënteerd programmeren.


